Public Enum WhatToWorkOn As Integer
    All = 0

    PostFSforRiskRating = 1
    MasterAccounts = 2
    StaticValues = 3
    ImportedValues = 4
    CalculatedValues = 5
    ImportedValuesStatements = 6
    CalculatedValuesStatements = 7
    MasterAccountsStatements = 8
    StatementImportedAndCalculated = 9


    Free = 10


    CalculateStmtsFromYTDs = 20
    CalculateQuarterlyFromMonthlies = 21
    CalculateYTDsFromStmts = 22
    NavigationTreeFill = 30
    RunMonthEnd = 40

End Enum
Public Enum NodeType As Integer
    Portfolio = 1

    Reports = 20
    ReportGroup = 21
    Report = 22
    StressTestReportValue = 23

    Loans = 30
    Loan = 31
    FinStmtRisk = 32
    FinStmt = 33
    AllFinStmt = 34

    AccountsMapping = 40
    AccountMapping = 41

    CalculationSetup = 50
    MasterAccounts = 51
    StaticValues = 52
    ImportedValues = 53
    CalculatedValues = 54

    TrashCan = 60
End Enum

Public Enum ItemType As Integer
    Connection = 1

    MasterAccntIncomeStatement = 10
    MasterAccntBalanceSheet = 11
    StaticValue = 12
    ImportedValue = 13
    CalculatedValue = 14

    AccountIncomeStatement = 20
    AccountBalanceSheet = 21

    FinancialStmtAttributes = 30

    FinancialStatement = 40
    FinancialStatementRiskRated = 41

    ActionItem = 50
End Enum

Public Enum StatementType As Integer
    Qtr1 = 1
    Qtr2 = 2
    Qtr3 = 3
    Qtr4 = 4
    Monthly = 5
    SemiAnnual = 6
    Annual = 7
    YTD = 11
    Quarterly = 12
End Enum

Public Class clsLoanFilterValue
    Private mID As Int32
    Private mValueType As ItemType
    Private mValueID As Int32
    Private mLabel As String

    Public Property ID() As Int32
        Get
            Return mID
        End Get
        Set(ByVal Value As Int32)
            mID = Value
        End Set
    End Property
    Public Property ValueType() As ItemType
        Get
            Return mValueType
        End Get
        Set(ByVal Value As ItemType)
            mValueType = Value
        End Set
    End Property
    Public Property ValueID() As Int32
        Get
            Return mValueID
        End Get
        Set(ByVal Value As Int32)
            mValueID = Value
        End Set
    End Property
    Public Property Label() As String
        Get
            Return mLabel
        End Get
        Set(ByVal Value As String)
            mLabel = Value
        End Set
    End Property
    Public Values() As String
End Class

Public Class clsStressTestValue
    Inherits clsLoanFilterValue

    Public Percent As Double
    Public Dollars As Double
    Public Format As String

    Public AffectedValueID As Int16
End Class

Public Class clsTrashCanItem
    Public IType As ItemType
    Public PortfolioID As Int16
    Public Name As String
    Public DateDeleted As Date
    Public Table As String
    Public IDField As String
    Public IDFieldID As Int64
    Public StatusField As String
    Public User As String
End Class

Public Class clsStmtType
    'Used to show basic statemnt types and not to have to go to the database to fill a combo box

    Private _Name As String
    Private _ID As StatementType


    Public ReadOnly Property Name() As String
        Get
            Select Case _ID
                Case StatementType.Monthly
                    Return "Monthly"
                Case StatementType.SemiAnnual
                    Return "SemiAnnual"
                Case StatementType.Annual
                    Return "Annual"
                Case 12
                    Return "Quarterly"
            End Select
        End Get
    End Property
    Public Property ID() As StatementType
        Get
            Return _ID
        End Get
        Set(ByVal Value As StatementType)
            _ID = Value
        End Set
    End Property
End Class


Public Class clsConnection
    Private mID As Int64 'Had to implemet ID and Name as property so my binding works
    Private mName As String
    Public Description As String
    Public Connection As String
    Public TestConnection As String
    Public Status As String
    Public Order As Int16

    Public Property Name() As String
        Get
            Name = mName
        End Get
        Set(ByVal Value As String)
            mName = Value
        End Set
    End Property
    Public Property ID() As Int16
        Get
            ID = mID
        End Get
        Set(ByVal Value As Int16)
            mID = Value
        End Set
    End Property
End Class

Public Class clsMasterAccount
    Inherits BaseObject

    Public Description As String
    Public AccntType As ItemType    'Added later, might be some places where this is not used to figure out the type of the master account
    Public Formula As String        'Added later - keeps formula for an account
    Public FormulaRTF As String     'Added later - keeps formula in RTF format (rich text format)
    Public MappingID As Int64       'Added later - keeps ID of the record for mapping (where formulas are stored)
    Public Value As String
    Public Trend As String
    Public NextValue As String
    Public Correct As Boolean       'Added on 06/03/04 - if more account from FS mapped more than once then incorrect, if every account in formula only once than correct


End Class
Public Class clsNodeType

    Public ID As Int64
    Public Type As NodeType
    Public FullyFilled As Boolean = False
    Public Description As String
    Public ParentID As Int64    'Reports can be part of a group and parent id is group ID
    Public Hidden As Boolean    'For reports (stress test), but maybe used later for something else too...

    Public Sub New(ByVal intID As Int64, ByVal NType As NodeType)
        Type = NType
        ID = intID
    End Sub
    Public Sub New(ByVal intID As Int64, ByVal NType As NodeType, ByVal boolHidden As Boolean)
        Type = NType
        ID = intID
        Hidden = boolHidden
    End Sub
    Public Sub New(ByVal intID As Int64, ByVal NType As NodeType, ByVal intParentID As Int64, ByVal strDesc As String)
        ID = intID
        Type = NType
        ParentID = intParentID
        Description = strDesc
    End Sub
    Public Sub New(ByVal intID As Int64, ByVal NType As NodeType, ByVal intParentID As Int64, ByVal strDesc As String, ByVal boolHidden As Boolean)
        ID = intID
        Type = NType
        ParentID = intParentID
        Description = strDesc
        Hidden = boolHidden
    End Sub
    Public Sub New()

    End Sub
End Class
Public Class clsDeletedItem
    Public Name As String
    Public ID As Int64
    Public DelType As ItemType
End Class

Public Class clsAccount
    Inherits BaseObject

    Public Line As String
    Public AccntNumber As String
    Public Amount As Double
    Public AccntType As ItemType
    Public Checked As Boolean   'Used when creating statement from other statemetns to mark line as being checked

End Class

Public Class clsStaticValue
    Inherits BaseObject

    Public Connection As New clsConnection
    Public Field As String
    Public Formula As String
    Public FormulaRTF As String
    Public Result As String
End Class

Public Class clsImportedValue
    Inherits clsStaticValue
End Class

Public Class clsCalculatedValue
    Inherits BaseObject

    Public Description As String
    Public Formula As String
    Public FormulaRTF As String
    Public Result As String
End Class

Public Class BaseObject
    Public Name As String
    Public ID As Int64
    Public Order As Single
    Public Heading As Boolean
    Public Formating As String
End Class

Public Class clsActionItem

    Public ID As Int64
    Public LoanID As Int64
    Public TargetDate As Date
    Public AccountablePerson As String
    Public ActionItem As String
    Public Results As String

End Class

Public Class clsLoan

#Region "Sort Capability for Array"
    '10/7/04 dbujak Needs this so I can use the class in arraylist and perform sorting
    Implements IComparable

    Public Enum LoanSortBy As Integer
        LoanIDAsc = 0
        LoanIDDesc = 1
        LoanNumberAsc = 2
        LoanNumberDesc = 3
        LoanNameAsc = 4
        LoanNameDesc = 5
    End Enum

    Private mSortBy As LoanSortBy

    Public Function CompareTo(ByVal obj As Object) As Integer Implements System.IComparable.CompareTo
        Dim objLoan As clsLoan = CType(obj, clsLoan)

        Select Case mSortBy
            Case LoanSortBy.LoanIDAsc
                CompareTo = Me.ID < objLoan.ID
            Case LoanSortBy.LoanIDDesc
                CompareTo = Me.ID > objLoan.ID
            Case LoanSortBy.LoanNumberAsc
                CompareTo = Me.LoanNumber < objLoan.LoanNumber
            Case LoanSortBy.LoanNumberDesc
                CompareTo = Me.LoanNumber > objLoan.LoanNumber
            Case LoanSortBy.LoanNameAsc
                CompareTo = Me.Name < objLoan.Name
            Case LoanSortBy.LoanNameDesc
                CompareTo = Me.Name > objLoan.Name
        End Select

    End Function
    Public Property SortBy() As LoanSortBy
        Get
            Return mSortBy
        End Get
        Set(ByVal Value As LoanSortBy)
            mSortBy = Value
        End Set
    End Property
    'end 10/7/04 dbujak Needs this so I can use the class in arraylist and perform sorting

#End Region




    Private mID As Int64
    Private mLoanNumber As String
    Public Name As String
    Public PortfolioID As Int32
    Public StatementID As Int64     'Need this when calculating imported and calcualted values
    Public UserSelected As Boolean  'Use this when user picks what loans to run reports for
    Public FilterValues() As clsLoanFilterValue 'Need this when selecting loans for reports (for example) and want to filter based on say asset manager


    Public Property ID() As Int64
        Get
            ID = mID
        End Get
        Set(ByVal Value As Int64)
            mID = Value
        End Set
    End Property
    Public Property LoanNumber() As String
        Get
            LoanNumber = mLoanNumber
        End Get
        Set(ByVal Value As String)
            mLoanNumber = Value
        End Set
    End Property

End Class

Public Class clsFS
    Private mID As Int64
    Private mPeriodEnd As Date
    Private mStmtType As StatementType
    Public Accountant As String = ""
    Public Analyst As String = ""
    Public AuditMethod As String = ""
    Public Notes As String = ""
    Public Accounts() As clsAccount 'Used when calculating quarterly based on monthlies

    Public Property PeriodEnd() As Date
        Get
            Return mPeriodEnd
        End Get
        Set(ByVal Value As Date)
            mPeriodEnd = Value
        End Set
    End Property
    Public ReadOnly Property PeriodEndString() As String
        Get
            Return mPeriodEnd.ToShortDateString & " - " & mStmtType.ToString
        End Get
    End Property
    Public Property StmtType() As StatementType
        Get
            Return mStmtType
        End Get
        Set(ByVal Value As StatementType)
            mStmtType = Value
        End Set
    End Property
    Public Property ID() As Int64
        Get
            Return mID
        End Get
        Set(ByVal Value As Int64)
            mID = Value
        End Set
    End Property

End Class

Public Class clsStressTestTreeViewHelp
    Public Enum Status As Integer
        NotFilled = 0
        Filled = 1
        Done = 2
        KidsCheckedForUnload = 3
        CheckedForUnload = 4
    End Enum

    Private mstrFormula As String
    Private mboolHasChildren As Boolean
    Private mType As ItemType
    Private mName As String
    Private mID As Int64
    Private mstrConnection As String

    Public Sub New(ByVal Type As ItemType, ByVal Name As String, ByVal ID As Int64, ByVal Formula As String, ByVal strConnection As String)
        mType = Type
        mName = Name
        mID = ID
        mstrFormula = Formula
        mboolHasChildren = HasChildren(Formula)
        NodeStatus = Status.NotFilled
        mstrConnection = strConnection
    End Sub

    Private Function HasChildren(ByVal strFormula As String) As Boolean
        strFormula = strFormula.ToUpper
        'If Income statement or balance sheet, has children = false
        Select Case mType
            Case ItemType.MasterAccntIncomeStatement, ItemType.MasterAccntBalanceSheet
                Return False
            Case ItemType.ImportedValue, ItemType.CalculatedValue, ItemType.StaticValue
                If strFormula.IndexOf("{STATIC.") > -1 Then
                    Return True
                End If
                If strFormula.IndexOf("{INCOME.") > -1 Then
                    Return True
                End If
                If strFormula.IndexOf("{BALANCE.") > -1 Then
                    Return True
                End If
                If strFormula.IndexOf("{IMPORTED.") > -1 Then
                    Return True
                End If
                If strFormula.IndexOf("{CALCULATED.") > -1 Then
                    Return True
                End If
        End Select

        Return False
    End Function

    Public ReadOnly Property ObjectType() As ItemType
        Get
            Return mType
        End Get
    End Property
    Public ReadOnly Property ObjectName() As String
        Get
            Return mName
        End Get
    End Property
    Public ReadOnly Property ObjectID() As Int64
        Get
            Return mID
        End Get
    End Property
    Public ReadOnly Property ObjectFormula() As String
        Get
            Return mstrFormula
        End Get

    End Property
    Public ReadOnly Property ObjectHasChildren() As Boolean
        Get
            Return mboolHasChildren
        End Get
    End Property
    Public ReadOnly Property Connection() As String
        Get
            Return mstrConnection
        End Get
    End Property
    Public NodeStatus As clsStressTestTreeViewHelp.Status
    Public NeedsUpdate As Boolean = False

End Class

#Region " Reports Stuff "
Public Enum ReportType As Integer
    TwoDim = 1
    ThreeDim = 2
    Group = 3
End Enum

Public Enum PaperSize As Integer
    Letter = 0
    Legal = 1
End Enum

Public Enum PageOrientation As Integer
    Landscape = 0
    Portrait = 1
End Enum

Public Enum Align As Byte
    NotDefind = 0
    Left = 1
    Center = 2
    Right = 3
End Enum

Public Class ReportBasic
    Public ID As Int16
    Public Name As String
    Public Description As String
    Public ParentID As Int16
    Public Type As ReportType   'If Group report gen info does not apply
    Public Order As Int16
    Public PortfolioID As Int16
    Public Status As Int16
End Class

Public Class PageInfo
    Public PageNumber As Byte   'for 2D always 1 for 3D could be up to 3
    Public Logo As Boolean
    Public LogoWidth As Int16
    Public FACTS As Boolean     'writes FACTS on the screen (full name)
    Public FACTSShort As Boolean    'write only FACTS (short)
    Public FACTSFont As Byte    'font size for FACTS
    Public Title As String
    Public TitleFont As Byte
    Public HeaderHeight As Int16
    Public Footer As String
    Public FooterFont As Byte
    Public FooterHeight
End Class

Public Class Report
    Inherits ReportBasic

    Public MarginTop As Int16
    Public MarginBottom As Int16
    Public MarginRight As Int16
    Public MarginLeft As Int16
    Public Paper As PaperSize
    Public PageOrientation As PageOrientation
    Public ReportingType As StatementType
    Public NumberOfPeriods As Int16
    Public NumberOfPages As Int16 = 1

End Class

Public Class Field2DReport
    Public Label As String
    Public Width As Int16
    Public Order As Int16
    Public FieldAlign As Align
    Public FieldFormat As String

    Private mstrField As String
    Private mFieldType As ItemType
    Private mstrFieldTrimmed As String  'Keeps only field name whithout spaces
    Private mstrFieldNotTrimmed As String   'Keeps fieldl name with the sapces
    Private mstrValue As String
    Private mboolNoPrint As Boolean
    Private mstrCriteria As String
    Private mstrCriteriaMath As String
    Private mstrCriteriaParam As String

    'Added later 12/07/04
    Private mObjectID As Int16


    Public ReadOnly Property NoPrint_CriteriaBased() As Boolean
        Get
            Return mboolNoPrint
        End Get
    End Property

    Public Property Criteria() As String
        Get
            Return mstrCriteria
        End Get
        Set(ByVal Value As String)
            mstrCriteria = Value.Trim

            'Exit if no criteria
            If mstrCriteria = "" Then Exit Property

            Value = mstrCriteria

            'Get the math part (exp: criteria: < 0.2; math part is '<', parameter is '0.2'
            Dim boolMoreMath As Boolean
            Do
                'Get first character to evaluate to see if <,> or =
                Dim strHelp As String = Value.Chars(0)
                'remove first character
                Value = Value.Remove(0, 1)
                If strHelp = "<" Or strHelp = ">" Or strHelp = "=" Then
                    'If <,> or = then add it to the math part
                    mstrCriteriaMath = mstrCriteriaMath & strHelp
                    boolMoreMath = True
                Else
                    'The rest is the parameter
                    mstrCriteriaParam = Value.Trim
                    boolMoreMath = False
                End If
            Loop While boolMoreMath = True
        End Set
    End Property

    Public Property Value() As String
        Get
            Return mstrValue
        End Get
        Set(ByVal Value As String)
            mstrValue = Value
            'Check if need to run criteria
            If Criteria <> "" Then
                mboolNoPrint = CriteriaEval()
            Else
                mboolNoPrint = False
            End If
            'Check if need to apply formating

            If Me.FieldFormat <> "" Then
                'Check if date or number format
                If FieldFormat.IndexOf("d") > 0 Or FieldFormat.IndexOf("m") > 0 Or FieldFormat.IndexOf("y") > 0 Then 'Date
                    If Value <> "" Then
                        Try
                            mstrValue = Convert.ToDateTime(Value).ToString(FieldFormat)
                        Catch ex As Exception
                            mstrValue = Value
                        End Try
                    Else
                        mstrValue = ""
                    End If
                Else    'number
                    If Value <> "" Then
                        Try
                            mstrValue = Convert.ToDouble(Value).ToString(FieldFormat)
                        Catch ex As Exception
                            mstrValue = Value
                        End Try
                    Else
                        mstrValue = ""
                    End If
                End If
            End If

        End Set
    End Property

    Private Function CriteriaEval() As Boolean

        'Check what trying to evaluate
        Select Case mstrCriteriaMath
            Case "<"    'Less                   (only numbers)
                If StringToNumber(mstrValue) < StringToNumber(mstrCriteriaParam) Then
                    'Print 
                    mboolNoPrint = False
                Else
                    'don't print
                    mboolNoPrint = True
                End If
            Case ">"    'Greater                (only numbers)
                If StringToNumber(mstrValue) > StringToNumber(mstrCriteriaParam) Then
                    'Print 
                    mboolNoPrint = False
                Else
                    'don't print
                    mboolNoPrint = True
                End If
            Case "="    'Equals                 (numbers and text)
                'check if number first
                If IsNumeric(mstrCriteriaParam) = True Then
                    If StringToNumber(mstrValue) = StringToNumber(mstrCriteriaParam) Then
                        'Print 
                        mboolNoPrint = False
                    Else
                        'don't print
                        mboolNoPrint = True
                    End If
                Else
                    'String
                    If mstrValue = mstrCriteriaParam Then
                        mboolNoPrint = False
                    Else
                        mboolNoPrint = True
                    End If
                End If
            Case "<>"   'Different              (numbers and text)
                'check if number first
                If IsNumeric(mstrCriteriaParam) = True Then
                    If StringToNumber(mstrValue) <> StringToNumber(mstrCriteriaParam) Then
                        'Print 
                        mboolNoPrint = False
                    Else
                        'don't print
                        mboolNoPrint = True
                    End If
                Else
                    'String
                    If mstrValue <> mstrCriteriaParam Then
                        mboolNoPrint = False
                    Else
                        mboolNoPrint = True
                    End If
                End If
            Case "<=", "=<" 'Less or equals     (only numbers)
                If StringToNumber(mstrValue) <= StringToNumber(mstrCriteriaParam) Then
                    'Print 
                    mboolNoPrint = False
                Else
                    'don't print
                    mboolNoPrint = True
                End If
            Case ">=", "=>" 'Greater or equals  (only numbers)
                If StringToNumber(mstrValue) >= StringToNumber(mstrCriteriaParam) Then
                    'Print 
                    mboolNoPrint = False
                Else
                    'don't print
                    mboolNoPrint = True
                End If
        End Select

        Return mboolNoPrint
    End Function

    Private Function StringToNumber(ByVal str As String) As Double
        If str.Trim = "" Then
            Return 0
        Else
            Return CType(str.Trim, Double)
        End If
    End Function

    Public Property Field() As String
        Get
            Return mstrField
        End Get
        Set(ByVal Value As String)
            mstrField = Value

            ExtractInfoFromField(Value)
        End Set
    End Property

    Private Sub ExtractInfoFromField(ByVal Field As String)
        'Get the item type

        'First trim { and }
        Field = Field.Replace("{", "")
        Field = Field.Replace("}", "")

        'See where the separator is
        Dim i As Int16 = Field.IndexOf(".")
        'Get the type
        Dim strHelp As String = Field.Substring(0, i)
        Select Case strHelp.ToUpper
            Case "STATIC"
                mFieldType = ItemType.StaticValue
            Case "IMPORTED"
                mFieldType = ItemType.ImportedValue
            Case "CALCULATED"
                mFieldType = ItemType.CalculatedValue
            Case "INCOME"
                mFieldType = ItemType.MasterAccntIncomeStatement
            Case "BALANCE"
                mFieldType = ItemType.MasterAccntBalanceSheet
        End Select


        'Get the field name
        mstrFieldNotTrimmed = Field.Substring(i + 1, Len(Field) - i - 1)
        mstrFieldTrimmed = mstrFieldNotTrimmed.Trim
    End Sub

    Public ReadOnly Property FieldNotTrimmed() As String
        Get
            Return mstrFieldNotTrimmed
        End Get
    End Property
    Public ReadOnly Property FieldTrimmed() As String
        Get
            Return mstrFieldTrimmed
        End Get
    End Property

    Public Property FieldType() As ItemType
        Get
            Return mFieldType
        End Get
        Set(ByVal Value As ItemType)
            mFieldType = Value
        End Set
    End Property

    Public Property ObjectID() As Int16
        Get
            Return mObjectID
        End Get
        Set(ByVal Value As Int16)
            mObjectID = Value
        End Set
    End Property
End Class


Public Class Report2D
    Inherits Report

    Public Page As PageInfo
    Public Fields() As Field2DReport
    Public RecordHeaderFields() As Field2DReport

    Public TableHeaderFont As Byte  'Table header is top part of a report - where fields captions are
    Public TableHeaderBold As Boolean
    Public TableHeaderColor As System.Drawing.Color
    Public TableHeaderHeight As Int16
    Public TableHeaderGrid As Boolean

    Public RecordHeader As Boolean
    Private mRecordHeaderFormula As String
    Public Property RecordHeaderFormula() As String
        Get
            Return mRecordHeaderFormula
        End Get
        Set(ByVal Value As String)
            mRecordHeaderFormula = Value

            'extract fiedls from the formula
            Me.GetFieldsFromFormula2(Value)
        End Set
    End Property
    Private Sub GetFieldsFromFormula2(ByVal strFormula As String)
        If strFormula = "" Then
            RecordHeaderFields = Nothing
            Exit Sub
        End If

        Dim Formula(,) As String

        Dim strOpen(), strClose() As String
        strOpen = strFormula.Split("{")
        strClose = strFormula.Split("}")

        ReDim Preserve Formula(1, UBound(strOpen) - 1)

        Dim i, intStart, intEnd As Int16, intDot As Int16
        For i = 0 To UBound(strOpen) - 1
            Dim strHelp As String
            intStart = intStart + strOpen(i).Length + 1
            intEnd = intEnd + strClose(i).Length + 1
            strHelp = strFormula.Substring(intStart, intEnd - intStart - 1)
            intDot = strHelp.IndexOf(".")


            If intDot > -1 Then
                Formula(0, i) = strHelp.Substring(0, intDot)
                Formula(1, i) = strHelp.Substring(intDot + 1)
            Else
                Formula(0, i) = ""
                Formula(1, i) = strHelp
            End If
        Next

        'Assign fields to record header
        ReDim RecordHeaderFields(Formula.GetUpperBound(1))
        For i = 0 To Formula.GetUpperBound(1)
            Dim Field As New Field2DReport
            Field.Field = "{" & Formula(0, i) & "." & Formula(1, i) & "}"

            RecordHeaderFields(i) = Field
        Next
    End Sub

    Public RecordHeaderFormulaWithValues As String

    Public RecordHeaderFont As Byte
    Public RecordHeaderBold As Boolean
    Public RecordHeaderColor As System.Drawing.Color
    Public RecordHeaderHeight As Int16
    Public RecordHeaderGrid As Boolean

    Public DataFont As Byte
    Public DataBold As Boolean
    Public DataColorOdd As System.Drawing.Color
    Public DataColorEven As System.Drawing.Color
    Public DataHeight As Int16
    Public DataGrid As Boolean
End Class

#End Region




