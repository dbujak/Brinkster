
using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Security.Cryptography;


namespace DBujakEncryption
{
	public class DBujakEncryption
	{
		public enum EncryptionAlgorithm: int
		{
			RijndaelManaged = 1,
			DESCryptoServiceProvider = 2,
			RC2CryptoServiceProvider = 3,
			TripleDESCryptoServiceProvider = 4
		}

		private const string _Key = "RealHardKey";
		private const string _IV = "RealHardIV";
		private const int DefaultAlgorithm = 1;

	#region Conversion Stuff
		private byte[] StringToBytes(string str)
		{
			if (str.Length > 0)
			{
				return Encoding.ASCII.GetBytes(str);
			}
			return null;
		}

		private string RightSizeKey(string Key)
		{
			if (Key.Length.CompareTo(0) >= 0 && Key.Length.CompareTo(15) <= 0)
			{
					Key = Key.PadRight(16);
			}
			else if (Key.Length.CompareTo(17) >= 0 && Key.Length.CompareTo(31) <= 0)
			{
					Key = Key.PadRight(32);
			}
			else if (Key.Length.CompareTo(33) >= 0 && Key.Length.CompareTo(47) <= 0)
			{
					Key = Key.PadRight(48);
			}
			else if (Key.Length.CompareTo(48) > 0)
			{
					Key = Key.Substring(0, 48);
			}

			return Key;
		}

		private string RightSizeIV(string IV)
		{

			if (IV.Length.CompareTo(0) >= 0 && IV.Length.CompareTo(15) <= 0)
			{
					IV = IV.PadRight(16);
			}
			else if (IV.Length.CompareTo(16) > 0)
			{
					IV = IV.Substring(0.16);
			}

			return IV;
		}
	#endregion

	#region Encryption part

		private byte[] _Encrypt(byte[] InByte, byte[] Key, byte[] IV, EncryptionAlgorithm Algorithm)
		{
			//***************This function actually does the encryption
			MemoryStream OutStream = new MemoryStream();
			byte[] OutByte = null;
			SymmetricAlgorithm Encryptor = null;
			CryptoStream EncStream = null;

			try
			{

				switch (Algorithm)
				{
					case EncryptionAlgorithm.RijndaelManaged:
						Encryptor = new RijndaelManaged();
						break;
					case EncryptionAlgorithm.DESCryptoServiceProvider:
						Encryptor = new DESCryptoServiceProvider();
						break;
					case EncryptionAlgorithm.RC2CryptoServiceProvider:
						Encryptor = new RC2CryptoServiceProvider();
						break;
					case EncryptionAlgorithm.TripleDESCryptoServiceProvider:
						Encryptor = new TripleDESCryptoServiceProvider();
						break;
				}
				//These should be set up this way by default
				Encryptor.Mode = CipherMode.CBC;
				Encryptor.Padding = PaddingMode.PKCS7;

				//Create Crypto stream
				EncStream = new CryptoStream(OutStream, Encryptor.CreateEncryptor(Key, IV), CryptoStreamMode.Write);


				//Use Crypto stream to write byte array to be encrypted into another stream (OutStream)
				EncStream.Write(InByte, 0, InByte.Length);
				EncStream.FlushFinalBlock();
				//Write encrypted stream to OutByte() 
				byte[] Help = new byte[OutStream.Length];
				OutStream.Seek(0, SeekOrigin.Begin);
				OutStream.Read(Help, 0, OutStream.Length);
				OutByte = Help;


			}
			catch (Exception ex)
			{
				throw new Exception("Error encrypting: " + ex.Message.ToString());
			}
			finally
			{
				if (EncStream != null)
				{
					EncStream.Close();
				}
			}

			//Return Bytes
			return OutByte;

		}


		public string Encrypt(string strText)
		{
			byte[] Key = null;
				byte[] IV = null;
			byte[] InByte = Encoding.Unicode.GetBytes(strText);
			byte[] OutByte = null;

			//Get default key and IV; encrypt
			Key = StringToBytes(_Key);
			IV = StringToBytes(_IV);
			OutByte = _Encrypt(InByte, Key, IV, DefaultAlgorithm);
			return Encoding.Unicode.GetString(OutByte);

		}

		public byte[] Encrypt(byte[] InByte)
		{
			byte[] Key = null;
				byte[] IV = null;

			//Get default key and IV; encrypt
			Key = StringToBytes(_Key);
			IV = StringToBytes(_IV);
			return _Encrypt(InByte, Key, IV, DefaultAlgorithm);
		}

		public string Encrypt(string strText, string strKey)
		{
			byte[] Key = null;
				byte[] IV = null;
			byte[] InByte = Encoding.Unicode.GetBytes(strText);
			byte[] OutByte = null;

			//Convert suplied key to byte; Get default IV; encrypt
			strKey = RightSizeKey(strKey); //Must be right size
			Key = StringToBytes(strKey);
			IV = StringToBytes(_IV);

			OutByte = _Encrypt(InByte, Key, IV, DefaultAlgorithm);
			return Encoding.Unicode.GetString(OutByte);
		}

		public byte[] Encrypt(byte[] InByte, string strKey)
		{
			byte[] Key = null;
				byte[] IV = null;

			//Convert suplied key to byte; Get default IV; encrypt
			strKey = RightSizeKey(strKey); //Must be right size
			Key = StringToBytes(strKey);
			IV = StringToBytes(_IV);

			return _Encrypt(InByte, Key, IV, DefaultAlgorithm);
		}

		public string Encrypt(string strText, string strKey, string strIV)
		{
			byte[] Key = null;
				byte[] IV = null;
			byte[] InByte = Encoding.Unicode.GetBytes(strText);
			byte[] OutByte = null;

			//Convert suplied key to byte; Convert suplied IV to byte; encrypt
			strKey = RightSizeKey(strKey); //Must be right size
			Key = StringToBytes(strKey);
			strIV = RightSizeIV(strIV);
			IV = StringToBytes(strIV);

			OutByte = _Encrypt(InByte, Key, IV, DefaultAlgorithm);
			return Encoding.Unicode.GetString(OutByte);
		}

		public byte[] Encrypt(byte[] InByte, string strKey, string strIV)
		{
			byte[] Key = null;
				byte[] IV = null;

			//Convert suplied key to byte; Convert suplied IV to byte; encrypt
			strKey = RightSizeKey(strKey); //Must be right size
			Key = StringToBytes(strKey);
			strIV = RightSizeIV(strIV);
			IV = StringToBytes(strIV);

			return _Encrypt(InByte, Key, IV, DefaultAlgorithm);
		}

		public string Encrypt(string strText, byte[] Key, byte[] IV, EncryptionAlgorithm Algorithm)
		{
			byte[] InByte = Encoding.Unicode.GetBytes(strText);
			byte[] OutByte = null;

			OutByte = _Encrypt(InByte, Key, IV, DefaultAlgorithm);
			return Encoding.Unicode.GetString(OutByte);
		}

		public byte[] Encrypt(byte[] InByte, byte[] Key, byte[] IV, EncryptionAlgorithm Algorithm)
		{

			return _Encrypt(InByte, Key, IV, DefaultAlgorithm);

		}

	#endregion

	#region Decryption part

		private byte[] _Decrypt(byte[] InByte, byte[] Key, byte[] IV, EncryptionAlgorithm Algorithm)
		{
			//***************This function actually does the decryption
			MemoryStream OutStream = new MemoryStream();
			byte[] OutByte = null;
			SymmetricAlgorithm Encryptor = null;
			CryptoStream EncStream = null;

			try
			{

				switch (Algorithm)
				{
					case EncryptionAlgorithm.RijndaelManaged:
						Encryptor = new RijndaelManaged();
						break;
					case EncryptionAlgorithm.DESCryptoServiceProvider:
						Encryptor = new DESCryptoServiceProvider();
						break;
					case EncryptionAlgorithm.RC2CryptoServiceProvider:
						Encryptor = new RC2CryptoServiceProvider();
						break;
					case EncryptionAlgorithm.TripleDESCryptoServiceProvider:
						Encryptor = new TripleDESCryptoServiceProvider();
						break;
				}
				Encryptor.Mode = CipherMode.CBC;
				Encryptor.Padding = PaddingMode.PKCS7;

				EncStream = new CryptoStream(OutStream, Encryptor.CreateDecryptor(Key, IV), CryptoStreamMode.Write);

				//Read decrypted stream into byte
				EncStream.Write(InByte, 0, InByte.Length);
				EncStream.FlushFinalBlock();
				//write decrypted stream into byte
				byte[] Help = new byte[OutStream.Length];
				OutStream.Seek(0, SeekOrigin.Begin);
				OutStream.Read(Help, 0, OutStream.Length);
				OutByte = Help;

			}
			catch (Exception ex)
			{
				throw new Exception("Error while decrypting: " + ex.Message.ToString());
			}
			finally
			{
				if (EncStream != null)
				{
					EncStream.Close();
				}
			}

			//Return decrypted data as byte
			return OutByte;

		}


		public string Decrypt(string strText)
		{
			byte[] Key = null;
				byte[] IV = null;
			byte[] InByte = Encoding.Unicode.GetBytes(strText);
			byte[] OutByte = null;

			//Get default key and IV; encrypt
			Key = StringToBytes(_Key);
			IV = StringToBytes(_IV);

			OutByte = _Decrypt(InByte, Key, IV, DefaultAlgorithm);
			return Encoding.Unicode.GetChars(OutByte);
		}

		public byte[] Decrypt(byte[] InByte)
		{
			byte[] Key = null;
				byte[] IV = null;

			//Get default key and IV; encrypt
			Key = StringToBytes(_Key);
			IV = StringToBytes(_IV);

			return _Decrypt(InByte, Key, IV, DefaultAlgorithm);
		}

		public string Decrypt(string strText, string strKey)
		{
			byte[] Key = null;
				byte[] IV = null;
			byte[] InByte = Encoding.Unicode.GetBytes(strText);
			byte[] OutByte = null;

			//Convert suplied key to byte; Get default IV; encrypt
			strKey = RightSizeKey(strKey); //Must be right size
			Key = StringToBytes(strKey);
			IV = StringToBytes(_IV);

			OutByte = _Decrypt(InByte, Key, IV, DefaultAlgorithm);
			return Encoding.Unicode.GetChars(OutByte);
		}

		public byte[] Decrypt(byte[] InByte, string strKey)
		{
			byte[] Key = null;
				byte[] IV = null;

			//Convert suplied key to byte; Get default IV; encrypt
			strKey = RightSizeKey(strKey); //Must be right size
			Key = StringToBytes(strKey);
			IV = StringToBytes(_IV);

			return _Decrypt(InByte, Key, IV, DefaultAlgorithm);
		}

		public string Decrypt(string strText, string strKey, string strIV)
		{
			byte[] Key = null;
				byte[] IV = null;
			byte[] InByte = Encoding.Unicode.GetBytes(strText);
			byte[] OutByte = null;

			//Convert suplied key to byte; Convert suplied IV to byte; encrypt
			strKey = RightSizeKey(strKey); //Must be right size
			Key = StringToBytes(strKey);
			strIV = RightSizeIV(strIV);
			IV = StringToBytes(strIV);

			OutByte = _Decrypt(InByte, Key, IV, DefaultAlgorithm);
			return Encoding.Unicode.GetChars(OutByte);
		}

		public byte[] Decrypt(byte[] InByte, string strKey, string strIV)
		{
			byte[] Key = null;
				byte[] IV = null;

			//Convert suplied key to byte; Convert suplied IV to byte; encrypt
			strKey = RightSizeKey(strKey); //Must be right size
			Key = StringToBytes(strKey);
			strIV = RightSizeIV(strIV);
			IV = StringToBytes(strIV);

			return _Decrypt(InByte, Key, IV, DefaultAlgorithm);
		}

		public string Decrypt(string strText, byte[] Key, byte[] IV, EncryptionAlgorithm Algorithm)
		{
			byte[] InByte = Encoding.Unicode.GetBytes(strText);
			byte[] OutByte = null;

			OutByte = _Decrypt(InByte, Key, IV, DefaultAlgorithm);
			return Encoding.Unicode.GetChars(OutByte);
		}

		public byte[] Decrypt(byte[] InByte, byte[] Key, byte[] IV, EncryptionAlgorithm Algorithm)
		{

			return _Decrypt(InByte, Key, IV, DefaultAlgorithm);

		}


	#endregion

	}



}